#ifndef COLORS_H
#define COLORS_H

void black();
void white();
void red();
void green();
void yellow();
void blue();
void purple();
void cyan();
void reset();

#endif
