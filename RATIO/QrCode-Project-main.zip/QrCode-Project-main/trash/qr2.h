#ifndef QR2_H
#define	QR2_H

int min(int x,int y);

int save_screenshot(int x1, int y1, int x2, int y2);

#endif

