#ifndef URLENCODER_H
#define	URLENCODER_H

char *strrev(char *str);

char* strToBin(int nb,size_t bits);

int charDeter(char c);

char* urlEncoder(char* url);


#endif
