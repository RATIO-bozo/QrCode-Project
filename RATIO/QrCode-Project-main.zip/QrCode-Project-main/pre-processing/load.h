#ifndef LOAD_H
#define LOAD_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

SDL_Surface* load_image(char path[]);

#endif
